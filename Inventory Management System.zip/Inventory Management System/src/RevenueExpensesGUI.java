import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class RevenueExpensesGUI extends JFrame {
    private final List<Transaction> transactions;
    private RevenueManager revenueManager;
    private ExpensesManager expensesManager;
    private final JLabel revenueLabel;
    private final JLabel expensesLabel;

    public RevenueExpensesGUI() {
        transactions = new ArrayList<>();

        setTitle("Revenue and Expenses Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 500);
        setLayout(new FlowLayout());
        getContentPane().setBackground(Color.PINK);  // Set the background color to pink

        JButton addTransactionButton = new JButton("Add Transaction");
        addTransactionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                TransactionDialog dialog = new TransactionDialog(RevenueExpensesGUI.this);
                dialog.setVisible(true);
            }
        });

        JButton calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double revenue = revenueManager.calculateRevenue();
                double expenses = expensesManager.calculateExpenses();
                double netProfit = revenue - expenses;

                revenueLabel.setText("Total Revenue: RM" + revenue);
                expensesLabel.setText("Total Expenses: RM" + expenses);
                JOptionPane.showMessageDialog(RevenueExpensesGUI.this,
                        "Net Profit: RM" + netProfit,
                        "Net Profit",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        revenueLabel = new JLabel("Total Revenue: ");
        expensesLabel = new JLabel("Total Expenses: ");

        add(addTransactionButton);
        add(calculateButton);
        add(revenueLabel);
        add(expensesLabel);
    }

    public void addTransaction(Transaction transaction) {
        transactions.add(transaction);
        revenueManager = new RevenueManager(transactions);
        expensesManager = new ExpensesManager(transactions);
    }
}

class Transaction {
    private final int transactionId;
    private final Date date;
    private final Product product;
    private final int quantity;
    private final String type; // "sale" or "purchase"

    public Transaction(int transactionId, Date date, Product product, int quantity, String type) {
        this.transactionId = transactionId;
        this.date = date;
        this.product = product;
        this.quantity = quantity;
        this.type = type;
    }

    // Getters and setters

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getType() {
        return type;
    }

}

class TransactionDialog extends JDialog {
    private final JTextField transactionIdField;
    private final JTextField dateField;
    private final JTextField productNameField;
    private final JTextField priceField;
    private final JTextField quantityField;
    private final JComboBox<String> typeComboBox;

    public TransactionDialog(JFrame parent) {
        super(parent, "Add Transaction", true);
        setSize(500, 500);
        setLayout(new GridLayout(7, 2));

        JLabel transactionIdLabel = new JLabel("Transaction ID:");
        transactionIdField = new JTextField();
        JLabel dateLabel = new JLabel("Date:");
        dateField = new JTextField();
        JLabel productNameLabel = new JLabel("Product Name:");
        productNameField = new JTextField();
        JLabel priceLabel = new JLabel("Price:");
        priceField = new JTextField();
        JLabel quantityLabel = new JLabel("Quantity:");
        quantityField = new JTextField();
        JLabel typeLabel = new JLabel("Type:");
        typeComboBox = new JComboBox<>(new String[]{"Sale", "Purchase"});

        JButton addButton = new JButton("Add");
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int transactionId = Integer.parseInt(transactionIdField.getText());
                Date date = new Date(dateField.getText());
                String productName = productNameField.getText();
                double price = Double.parseDouble(priceField.getText());
                int quantity = Integer.parseInt(quantityField.getText());
                String type = typeComboBox.getSelectedItem().toString();

                Product product = new Product(productName, price);
                Transaction transaction = new Transaction(transactionId, date, product, quantity, type);

                RevenueExpensesGUI parent = (RevenueExpensesGUI) getParent();
                parent.addTransaction(transaction);

                dispose();
            }
        });

        add(transactionIdLabel);
        add(transactionIdField);
        add(dateLabel);
        add(dateField);
        add(productNameLabel);
        add(productNameField);
        add(priceLabel);
        add(priceField);
        add(quantityLabel);
        add(quantityField);
        add(typeLabel);
        add(typeComboBox);
        add(addButton);
    }
}

class Product {
    private String name;
    private double price;

    public Product(String name, double price) {
        this.name = name;
        this.price = price;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
