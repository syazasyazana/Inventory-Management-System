import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.DecimalFormat;
import java.util.Scanner;

public class OrderGUI {
    private final JFrame frame;
    private Order order;


    public OrderGUI() {
        // Create the main frame
        frame = new JFrame("Order Details");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.setVisible(true);

        // Set the background color to pink pastel
        Color pinkPastel = new Color(249, 220, 215);
        frame.getContentPane().setBackground(pinkPastel);

        // Create the panel to hold order details
        JPanel orderPanel = new JPanel();
        orderPanel.setLayout(new GridLayout(7, 2, 10, 10));
        orderPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Add order details components to the panel
        JLabel orderIdLabel = new JLabel("Order ID:");
        JTextField orderIdField = new JTextField();
        orderPanel.add(orderIdLabel);
        orderPanel.add(orderIdField);

        JLabel customerNameLabel = new JLabel("Customer Name:");
        JTextField customerNameField = new JTextField();
        orderPanel.add(customerNameLabel);
        orderPanel.add(customerNameField);

        JLabel productNameLabel = new JLabel("Product Name:");
        JTextField productNameField = new JTextField();
        orderPanel.add(productNameLabel);
        orderPanel.add(productNameField);

        JLabel quantityLabel = new JLabel("Quantity:");
        JTextField quantityField = new JTextField();
        orderPanel.add(quantityLabel);
        orderPanel.add(quantityField);

        JLabel priceLabel = new JLabel("Price:");
        JTextField priceField = new JTextField();
        orderPanel.add(priceLabel);
        orderPanel.add(priceField);

        JLabel additionalRequirementsLabel = new JLabel("Additional Requirements:");
        JTextField additionalRequirementsField = new JTextField();
        orderPanel.add(additionalRequirementsLabel);
        orderPanel.add(additionalRequirementsField);

        JLabel supplierNameLabel = new JLabel("Supplier Name:");
        JTextField supplierNameField = new JTextField();
        orderPanel.add(supplierNameLabel);
        orderPanel.add(supplierNameField);

        // Create the place order button
        JButton placeOrderButton = new JButton("Place Order");
        placeOrderButton.setFont(new Font("Arial", Font.BOLD, 14));
        // Set the background color to pink
        pinkPastel = new Color(249, 220, 215);
        placeOrderButton.setBackground(pinkPastel);

        placeOrderButton.setForeground(Color.WHITE);

        placeOrderButton.addActionListener(e -> {
            // Create a new Order object
            int orderId = Integer.parseInt(orderIdField.getText());
            String customerName = customerNameField.getText();
            String productName = productNameField.getText();
            int quantity = Integer.parseInt(quantityField.getText());
            double price = Double.parseDouble(priceField.getText());
            String additionalRequirements = additionalRequirementsField.getText();
            String supplierName = supplierNameField.getText();

            // Assign the values to the Order object
            OrderGUI.this.order = new Order(orderId, customerName, productName, quantity, price, additionalRequirements, supplierName);

            // Create the OrderSuccessGUI instance to show the success message and order details
            OrderSuccessGUI successGUI = new OrderSuccessGUI(OrderGUI.this.order);

            // Close the GUI
            frame.dispose();
        });

        // Create a panel for the button
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(placeOrderButton);

        // Create a panel for the content
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());
        contentPanel.add(orderPanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Add the content panel to the frame
        frame.add(contentPanel);

        // Set the frame visible
        frame.setVisible(true);
    }

    public Order getOrder() {
        return order;
    }

    public void addWindowListener(WindowAdapter windowAdapter) {
        frame.addWindowListener(windowAdapter);
    }

    public void setOrderListener(OrderGUI.OrderListener orderListener) {
    }

    public void setVisible(boolean b) {
        if (b) {
            // Set the visibility of the current frame to true
            super.notify();
        } else {
            // Set the visibility of the current frame to false
            super.notify();
        }
    }

    public void setDefaultCloseOperation(int disposeOnClose) {
        switch (disposeOnClose) {
            case JFrame.HIDE_ON_CLOSE:
                setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
                break;
            case JFrame.DISPOSE_ON_CLOSE:
                setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                break;
            case JFrame.EXIT_ON_CLOSE:
                setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                break;
            default: 
                addWindowListener(new WindowAdapter() {
                    @Override
                    public void windowClosing(WindowEvent e) {}
                });
        }
    }

    public void dispose() throws InterruptedException {
        super.wait();
    }


    public static class OrderListener {
        void orderPlaced(Order order) {

        }
    }
}
class OrderSuccessGUI {
    private final JFrame frame;
    private Order order;

    public OrderSuccessGUI(Order order) {
        // Create the main frame
        frame = new JFrame("Order Success");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        // Create the panel to hold order details
        JPanel orderPanel = new JPanel();
        orderPanel.setLayout(new GridLayout(8, 2));
        frame.getContentPane().setBackground(Color.PINK);  // Set the background color to pink

        // Add order details components to the panel
        JLabel orderIdLabel = new JLabel("Order ID:");
        JLabel orderIdValue = new JLabel(String.valueOf(order.getOrderId()));
        orderPanel.add(orderIdLabel);
        orderPanel.add(orderIdValue);

        JLabel customerNameLabel = new JLabel("Customer Name:");
        JLabel customerNameValue = new JLabel(order.getCustomerName());
        orderPanel.add(customerNameLabel);
        orderPanel.add(customerNameValue);

        JLabel productNameLabel = new JLabel("Product Name:");
        JLabel productNameValue = new JLabel(order.getProductName());
        orderPanel.add(productNameLabel);
        orderPanel.add(productNameValue);

        JLabel quantityLabel = new JLabel("Quantity:");
        JLabel quantityValue = new JLabel(String.valueOf(order.getQuantity()));
        orderPanel.add(quantityLabel);
        orderPanel.add(quantityValue);

        JLabel priceLabel = new JLabel("Price:");
        JLabel priceValue = new JLabel(formatCurrency(order.getPrice()));
        orderPanel.add(priceLabel);
        orderPanel.add(priceValue);

        JLabel additionalRequirementsLabel = new JLabel("Additional Requirements:");
        JLabel additionalRequirementsValue = new JLabel(order.getAdditionalRequirements());
        orderPanel.add(additionalRequirementsLabel);
        orderPanel.add(additionalRequirementsValue);

        JLabel supplierNameLabel = new JLabel("Supplier Name:");
        JLabel supplierNameValue = new JLabel(order.getSupplierName());
        orderPanel.add(supplierNameLabel);
        orderPanel.add(supplierNameValue);

        JLabel statusLabel = new JLabel("Status:");
        JLabel statusValue = new JLabel(order.getStatus());
        orderPanel.add(statusLabel);
        orderPanel.add(statusValue);

        // Create the remove order button
        JButton removeOrderButton = new JButton("OK");
        removeOrderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int orderId = order.getOrderId();
                // Here you should call the removeOrder method from OrderManagement
                // For now, we will display a message that the order is removed
                JOptionPane.showMessageDialog(frame, orderId + ": SUCCESSFULLY ORDERED");
                frame.dispose();
            }
        });

        // Create a panel to hold the remove button
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(removeOrderButton);

        // Add the order panel and button panel to the frame
        frame.add(orderPanel, BorderLayout.CENTER);
        frame.add(buttonPanel, BorderLayout.SOUTH);

        // Set the frame visible
        frame.setVisible(true);
    }

    // Helper method to format the currency value
    private String formatCurrency(double value) {
        DecimalFormat decimalFormat = new DecimalFormat("RM #,##0.00");
        return decimalFormat.format(value);
    }

    public void dispose() {
        frame.dispose();
    }

    public void setOrder(Order order) {
        this.order = order;
    }

    public void addWindowListener(WindowAdapter windowAdapter) {
        frame.addWindowListener(windowAdapter);
    }

    public void setVisible(boolean b) {
        if (b) {
            // Set the visibility of the main menu frame
            setVisible(true);
        } else {
            // Set the visibility of the main menu frame to false
            setVisible(false);
        }
    }

}
class OrderManagement {
    private Admin admin;
    private Supplier supplier;

    public void setAdmin(Admin admin) {
        this.admin = admin;
    }

    public Admin getAdmin() {
        return admin;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public Order createOrder() {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Get user inputs for order details
        System.out.print("Enter Order ID: ");
        int orderId = scanner.nextInt();
        scanner.nextLine(); // Consume the remaining newline character

        System.out.print("Enter Customer Name: ");
        String customerName = scanner.nextLine();

        System.out.print("Enter Product Name: ");
        String productName = scanner.nextLine();

        System.out.print("Enter Quantity: ");
        int quantity = scanner.nextInt();

        System.out.print("Enter Price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume the remaining newline character

        System.out.print("Enter Additional Requirements: ");
        String additionalRequirements = scanner.nextLine();

        // Create a new Order object
        Order order = new Order(orderId, customerName, productName, quantity,
                price, additionalRequirements, supplier.getName());

        return order;
    }
}
class Order {
    private final int orderId;
    private final String customerName;
    private final String productName;
    private final int quantity;
    private final double price;
    private final String additionalRequirements;
    private String supplierName;
    private String status;

    public Order(int orderId, String customerName, String productName, int quantity, double price, String additionalRequirements, String supplierName) {
        this.orderId = orderId;
        this.customerName = customerName;
        this.productName = productName;
        this.quantity = quantity;
        this.price = price;
        this.additionalRequirements = additionalRequirements;
        this.supplierName = supplierName;
        this.status = "Pending"; // Initial status is set to 'Pending'
    }

    public int getOrderId() {
        return orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getPrice() {
        return price;
    }

    public String getAdditionalRequirements() {
        return additionalRequirements;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void displayOrderDetails() {
        System.out.println("Order Details:");
        System.out.println("Order ID: " + orderId);
        System.out.println("Customer Name: " + customerName);
        System.out.println("Product Name: " + productName);
        System.out.println("Quantity: " + quantity);
        System.out.println("Price: RM " + price);
        System.out.println("Additional Requirements: " + additionalRequirements);
        System.out.println("Supplier Name: " + supplierName);
        System.out.println("Status: " + status);
    }

    public void setSupplierName() {
        this.supplierName=supplierName;
    }
}
class Admin {
    private final String name;

    public Admin(String name) {
        this.name = name;
    }

    public void placeOrder(Order order, Supplier supplier) {
        // Process the order using the supplier
        supplier.processOrder(order);

        // Create the OrderSuccessGUI instance to display the order success message
        OrderGUI successGUI = new OrderGUI();
    }
}
class Supplier {
    private final String name;

    public Supplier(String name) {
        this.name = name;
    }

    public void processOrder(Order order) {
        // Update the order status
        order.setStatus("Processing");

        // Perform any necessary actions to process the order
        // For example, sending the order to the supplier's system

        // Display a message to the user
        System.out.println("Order processed by supplier: " + name);
    }

    public String getName() {
        return name;
    }
}
