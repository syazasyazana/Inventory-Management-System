import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class RoleBasedLoginGUI extends JFrame {

    //creates a combo box for the roles which are admin and user
    private final JComboBox<String> roleComboBox;
    //creates a label for username
    private final JLabel usernameLabel;
    //creates a label for password
    private final JLabel passwordLabel;
    //creates a text field for users to type into for username
    private final JTextField usernameTextField;
    //creates a text field fo users to input their password
    private final JPasswordField passwordField;
    //creates a login button
    private final JButton loginButton;
    //creates a register button
    private final JButton registerButton;

    private final Map<String, Map<String, String>> registeredUsers;

    public RoleBasedLoginGUI () {
        //sets frame requirements
        setTitle("Role-Based Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new FlowLayout());
        Color color=new Color(204, 204, 255);
        getContentPane().setBackground(color);
        getContentPane().setBackground(Color.PINK);  // Set the background color to pink


        //creates separate hashmap for the admin and user info to be stored into
        registeredUsers = new HashMap<>();
        registeredUsers.put("Admin", new HashMap<>());
        registeredUsers.put("User", new HashMap<>());

        //creates the role combo box
        String[] roles = {"Admin", "User"};
        roleComboBox = new JComboBox<>(roles);
        add(roleComboBox);


        usernameLabel = new JLabel("Username:");
        //sets the layout of the username label
        add(usernameLabel,FlowLayout.LEFT);

        usernameTextField = new JTextField(20);
        //sets the layout for the username text field
        add(usernameTextField,FlowLayout.CENTER);

        passwordLabel = new JLabel("Password:");
        add(passwordLabel);

        passwordField = new JPasswordField(20);
        add(passwordField);

        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //gets the input for role,username and password
                String role = (String) roleComboBox.getSelectedItem();
                String username = usernameTextField.getText();
                String password = new String(passwordField.getPassword());

                try {
                    //checks if the input is valid or not
                    if (validateCredentials(role, username, password)) {
                        JOptionPane.showMessageDialog(null, role + " login successful!");
                        showMainMenu(role); // Show the main menu based on the user's role
                        dispose(); // Close the login frame after successful login
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid credentials!");
                    }
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage());
                }
            }
        });
        add(loginButton, new BorderLayout());

        //register button for new users
        registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //opens a new panel where new users can register themselves with username,password and user type
                openRegisterPanel();
            }
        });
        add(registerButton);

        setVisible(true);
    }

    //checks if there is already information stored in the hashmap which indicates registered users
    private boolean validateCredentials(String role, String username, String password) {
        if (registeredUsers.containsKey(role)) {
            Map<String, String> users = registeredUsers.get(role);
            if (users.containsKey(username)) {
                String storedPassword = users.get(username);
                return storedPassword.equals(password);
            }
        }
        return false;
    }


    private void showMainMenu(String role) {
        JFrame mainMenuFrame = new JFrame(role + " Main Menu");
        mainMenuFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        mainMenuFrame.setSize(400, 300);
        mainMenuFrame.setLayout(new FlowLayout());
        JDialog registerFrame = null;
        registerFrame.getContentPane().setBackground(Color.PINK);

        if (role.equals("Admin")) {
            JButton manageRevenueExpensesButton = new JButton("Manage Revenue and Expenses");
            mainMenuFrame.add(manageRevenueExpensesButton);
            // Add action listener for the manage revenue and expenses button
            manageRevenueExpensesButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Open the revenue and expenses management GUI here
                    JOptionPane.showMessageDialog(null, "Open Revenue and Expenses Management GUI");
                }
            });
        } else if (role.equals("User")) {
            JButton manageStockButton = new JButton("Manage Stock");
            mainMenuFrame.add(manageStockButton);
            // Add action listener for the manage stock button
            manageStockButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    // Open the stock management GUI here
                    JOptionPane.showMessageDialog(null, "Open Stock Management GUI");
                }
            });
        }

        mainMenuFrame.setVisible(true);
    }

    private void openRegisterPanel() {
        //the basic requirements for the frame
        JFrame registerFrame = new JFrame("Register New User");
        registerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        registerFrame.setSize(400, 300);
        registerFrame.setLayout(new FlowLayout());
        registerFrame.getContentPane().setBackground(Color.PINK);

        JLabel userIdLabel = new JLabel("User ID:");
        JTextField userIdTextField = new JTextField(20);
        //sets the layout of the userid label
        registerFrame.add(userIdLabel,FlowLayout.LEFT);
        registerFrame.add(userIdTextField);

        JLabel userTypeLabel = new JLabel("User Type:");
        JComboBox<String> userTypeComboBox = new JComboBox<>(new String[]{"Admin", "User"});
        //sets the layout of the user type label
        registerFrame.add(userTypeLabel,FlowLayout.RIGHT);
        registerFrame.add(userTypeComboBox);

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        registerFrame.add(passwordLabel);
        registerFrame.add(passwordField);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String userId = userIdTextField.getText();
                String userType = (String) userTypeComboBox.getSelectedItem();
                String password = new String(passwordField.getPassword());


                //checks if the information already exists in the hashmap,if not stores and creates a new user
                if (registeredUsers.containsKey(userType)) {
                    Map<String, String> users = registeredUsers.get(userType);
                    if (!users.containsKey(userId)) {
                        users.put(userId, password);
                        JOptionPane.showMessageDialog(null, "User registered successfully!");
                        registerFrame.dispose();
                    } else {
                        JOptionPane.showMessageDialog(null, "User already exists!");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid user type!");
                }
            }
        });
        registerFrame.add(registerButton);

        registerFrame.setVisible(true);
    }

    //the login GUI is initialized and displayed on the screen.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new RoleBasedLoginGUI ();
            }
        });
    }}
