public class Main {
    public static void main(String[] args) {
        // Create the admin object
        Admin admin = new Admin("Admin Name");

        // Create the order management object and set the admin
        OrderManagement orderManagement = new OrderManagement();
        orderManagement.setAdmin(admin);

        // Create the supplier object with a name
        Supplier supplier = new Supplier("Supplier Name");
        orderManagement.setSupplier(supplier);

        // Create the OrderGUI instance to show the GUI for capturing user input
        Order order;
        OrderGUI orderGUI = new OrderGUI();

        // Retrieve the order object from the GUI
        order = orderGUI.getOrder();

        if (order != null) {
            // Display order information
            order.displayOrderDetails();
        }
    }
}
