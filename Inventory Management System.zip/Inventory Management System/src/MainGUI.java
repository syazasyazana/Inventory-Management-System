import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class MainGUI extends JFrame {
    private final JComboBox<String> roleComboBox;
    private final JTextField usernameTextField;
    private final JPasswordField passwordField;
    private RevenueExpensesGUI revenueExpensesGUI;
    private WarehouseManagementGUI warehouseManagementGUI;
    private StockManagementGUI stockManagementGUI;
    private OrderGUI orderGUI;

    private final Map<String, Map<String, String>> registeredUsers;

    public MainGUI() {
        // Set the background color to pink pastel
        Color pinkPastel = new Color(249, 220, 215);
        getContentPane().setBackground(pinkPastel);

        setTitle("Role-Based Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLayout(new FlowLayout());

        registeredUsers = new HashMap<>();
        registeredUsers.put("Admin", new HashMap<>());
        registeredUsers.put("User", new HashMap<>());

        String[] roles = {"Admin", "User"};
        roleComboBox = new JComboBox<>(roles);
        add(roleComboBox);

        JLabel usernameLabel = new JLabel("Username:");
        add(usernameLabel);

        usernameTextField = new JTextField(20);
        add(usernameTextField);

        JLabel passwordLabel = new JLabel("Password:");
        add(passwordLabel);

        passwordField = new JPasswordField(20);
        add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(e -> {
            String role = (String) roleComboBox.getSelectedItem();
            String username = usernameTextField.getText();
            String password = new String(passwordField.getPassword());

            try {
                if (validateCredentials(role, username, password)) {
                    JOptionPane.showMessageDialog(null, role + " login successful!");
                    assert role != null;
                    showMainMenu(role); // Show the main menu based on the user's role
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid credentials!");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "An error occurred: " + ex.getMessage());
            }
        });
        add(loginButton);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(e -> openRegisterPanel());
        add(registerButton);

        setVisible(true);
    }

    private boolean validateCredentials(String role, String username, String password) {
        if (registeredUsers.containsKey(role)) {
            Map<String, String> users = registeredUsers.get(role);
            if (users.containsKey(username)) {
                String storedPassword = users.get(username);
                return storedPassword.equals(password);
            }
        }
        return false;
    }

    private void showMainMenu(String role) {
        JFrame mainMenuFrame = new JFrame(role + " Main Menu");
        mainMenuFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        mainMenuFrame.setSize(400, 300);
        mainMenuFrame.setLayout(new FlowLayout());

        // Set the background color to pink pastel
        Color pinkPastel = new Color(249, 220, 215);
        mainMenuFrame.getContentPane().setBackground(pinkPastel);

        if (role.equals("Admin")) {
            JButton manageRevenueExpensesButton = new JButton("Manage Revenue and Expenses");
            mainMenuFrame.add(manageRevenueExpensesButton);
            // Add action listener for the manage revenue and expenses button
            manageRevenueExpensesButton.addActionListener(e -> openRevenueExpensesGUI());
            JButton manageWarehouseManagementButton = new JButton("Manage Warehouse");
            mainMenuFrame.add(manageWarehouseManagementButton);
            manageWarehouseManagementButton.addActionListener(e -> openWarehouseManagementGUI());
            JButton manageStockManagementButton = new JButton("Manage Stock");
            mainMenuFrame.add(manageStockManagementButton);
            manageStockManagementButton.addActionListener(e -> openStockManagementGUI());
            JButton placeOrderButton = new JButton("Place Order");
            mainMenuFrame.add(placeOrderButton);
            // Add action listener for the place order button
            placeOrderButton.addActionListener(e -> {
                mainMenuFrame.dispose(); // Close the main menu window
                showOrderGUI();
            });
        } else if (role.equals("User")) {
            JButton manageStockManagementButton = new JButton("Manage Stock");
            mainMenuFrame.add(manageStockManagementButton);
            manageStockManagementButton.addActionListener(e -> openStockManagementGUI());
            JButton manageWarehouseManagementButton = new JButton("Manage Warehouse");
            mainMenuFrame.add(manageWarehouseManagementButton);
            manageWarehouseManagementButton.addActionListener(e -> openWarehouseManagementGUI());
        }

        JButton exitButton = new JButton("Exit");
        mainMenuFrame.add(exitButton);
        exitButton.addActionListener(e -> {
            mainMenuFrame.dispose();
            System.exit(0);
        });

        mainMenuFrame.setVisible(true);
    }

    private void openRevenueExpensesGUI() {
        revenueExpensesGUI = new RevenueExpensesGUI();
        revenueExpensesGUI.setVisible(true);
        revenueExpensesGUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        revenueExpensesGUI.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                revenueExpensesGUI.dispose();
                showMainMenu((String) Objects.requireNonNull(roleComboBox.getSelectedItem()));
            }
        });
    }

    private void openWarehouseManagementGUI() {
        warehouseManagementGUI = new WarehouseManagementGUI();
        warehouseManagementGUI.setVisible(true);
        warehouseManagementGUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        warehouseManagementGUI.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                warehouseManagementGUI.dispose();
                showMainMenu((String) Objects.requireNonNull(roleComboBox.getSelectedItem()));
            }
        });
    }

    private void openStockManagementGUI() {
        stockManagementGUI = new StockManagementGUI();
        stockManagementGUI.setVisible(true);
        stockManagementGUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        stockManagementGUI.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                stockManagementGUI.dispose();
                showMainMenu((String) Objects.requireNonNull(roleComboBox.getSelectedItem()));
            }
        });
    }

    private void showOrderGUI() {
        orderGUI = new OrderGUI();
        orderGUI.setVisible(true);
        orderGUI.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        orderGUI.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                try {
                    orderGUI.dispose();
                } catch (InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
                showMainMenu((String) Objects.requireNonNull(roleComboBox.getSelectedItem()));
            }
        });
    }

    private void openRegisterPanel() {
        JFrame registerFrame = new JFrame("Register New User");
        registerFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        registerFrame.setSize(400, 300);
        registerFrame.setLayout(new FlowLayout());

        // Set the background color to pink pastel
        Color pinkPastel = new Color(249, 220, 215);
        registerFrame.getContentPane().setBackground(pinkPastel);

        JLabel userIdLabel = new JLabel("User ID:");
        JTextField userIdTextField = new JTextField(20);
        registerFrame.add(userIdLabel);
        registerFrame.add(userIdTextField);

        JLabel userTypeLabel = new JLabel("User Type:");
        JComboBox<String> userTypeComboBox = new JComboBox<>(new String[]{"Admin", "User"});
        registerFrame.add(userTypeLabel);
        registerFrame.add(userTypeComboBox);

        JLabel passwordLabel = new JLabel("Password:");
        JPasswordField passwordField = new JPasswordField(20);
        registerFrame.add(passwordLabel);
        registerFrame.add(passwordField);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(e -> {
            String userId = userIdTextField.getText();
            String userType = (String) userTypeComboBox.getSelectedItem();
            String password = new String(passwordField.getPassword());

            if (registeredUsers.containsKey(userType)) {
                Map<String, String> users = registeredUsers.get(userType);
                if (!users.containsKey(userId)) {
                    users.put(userId, password);
                    JOptionPane.showMessageDialog(null, "User registered successfully!");
                    registerFrame.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "User already exists!");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid user type!");
            }
        });
        registerFrame.add(registerButton);

        registerFrame.setVisible(true);
    }

    public static void main(String[] args) {
        new MainGUI();
    }
}