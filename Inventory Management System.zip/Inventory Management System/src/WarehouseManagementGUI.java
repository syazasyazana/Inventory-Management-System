import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class WarehouseManagementGUI extends JFrame {
    private DefaultListModel<StockItem> itemsListModel;
    private JList<StockItem> itemsList;
    private int itemCount;
    private JLabel itemCountLabel;

    public WarehouseManagementGUI() {
        // Set up the frame
        setTitle("Warehouse Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.PINK);  // Set the background color to pink

        // Create the main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        getContentPane().add(mainPanel);
        mainPanel.setBackground(Color.PINK);  // Set the background color to pink
        getContentPane().add(mainPanel);

        // Create the items list
        itemsListModel = new DefaultListModel<>();
        itemsList = new JList<>(itemsListModel);
        JScrollPane itemsScrollPane = new JScrollPane(itemsList);
        mainPanel.add(itemsScrollPane, BorderLayout.CENTER);

        // Create buttons
        JButton addItemButton = new JButton("Add Item");
        JButton removeItemButton = new JButton("Remove Item");
        JButton displayDetailsButton = new JButton("Display Details");

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addItemButton);
        buttonPanel.add(removeItemButton);
        buttonPanel.add(displayDetailsButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Create item count label
        itemCountLabel = new JLabel("Item Count: 0");
        mainPanel.add(itemCountLabel, BorderLayout.NORTH);

        // Add action listeners directly to the buttons
        addItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addItem();
            }
        });

        removeItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeItem();
            }
        });

        displayDetailsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayDetails();
            }
        });

        // Initialize the GUI with some sample data
        initializeSampleData();
    }

    private void initializeSampleData() {
        StockItem item1 = new StockItem("Iphone 14 Pro Max");
        StockItem item2 = new StockItem("Samsung Galaxy Ultra");
        StockItem item3 = new StockItem("Apple Vision");

        addItemToList(item1);
        addItemToList(item2);
        addItemToList(item3);
    }

    private void addItemToList(StockItem item) {
        itemsListModel.addElement(item);
        itemCount++;
        updateItemCountLabel();
    }

    private void removeItemFromList(StockItem item) {
        itemsListModel.removeElement(item);
        itemCount--;
        updateItemCountLabel();
    }

    private void addItem() {
        // Show an input dialog to get the item name from the user
        String name = JOptionPane.showInputDialog("Enter item name:");

        // Create a new StockItem object with the provided name
        StockItem newItem = new StockItem(name);

        // Add the item to the list
        addItemToList(newItem);
    }

    private void removeItem() {
        // Get the selected item from the list
        StockItem selectedItem = itemsList.getSelectedValue();

        // Remove the selected item from the list
        if (selectedItem != null) {
            removeItemFromList(selectedItem);
        } else {
            JOptionPane.showMessageDialog(this, "No item selected.");
        }
    }

    private void displayDetails() {
        // Get the selected item from the list
        StockItem selectedItem = itemsList.getSelectedValue();

        // Display the name of the item in a dialog box
        if (selectedItem != null) {
            JOptionPane.showMessageDialog(this, "Item: " + selectedItem.getName(), "Item Details", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No item selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateItemCountLabel() {
        itemCountLabel.setText("Item Count: " + itemCount);
    }

    public void updateItemList(Object[] toArray) {
        itemsListModel.clear();  // Clear the existing items from the list model

        for (Object obj : toArray) {
            if (obj instanceof StockItem) {
                StockItem stockItem = (StockItem) obj;
                itemsListModel.addElement(stockItem);  // Add the stock item to the list model
            }
        }

        itemCount = itemsListModel.getSize();  // Update the item count
        updateItemCountLabel();  // Update the item count label
    }

}
class WarehouseManagement {
    private List<StockItem> stockItems;

    public WarehouseManagement() {
        stockItems = new ArrayList<>();
    }

    public void addItem(String itemName) {
        StockItem newItem = new StockItem(itemName, 0);
        stockItems.add(newItem);
    }

    public boolean removeItem(String itemName) {
        StockItem itemToRemove = null;
        for (StockItem item : stockItems) {
            if (item.getName().equals(itemName)) {
                itemToRemove = item;
                break;
            }
        }
        if (itemToRemove != null) {
            stockItems.remove(itemToRemove);
        }
        return false;
    }

    public StockItem findStockItemByName(String itemName) {
        for (StockItem item : stockItems) {
            if (item.getName().equals(itemName)) {
                return item;
            }
        }
        return null;
    }

    public int getStockItemCount() {
        return stockItems.size();
    }
}

