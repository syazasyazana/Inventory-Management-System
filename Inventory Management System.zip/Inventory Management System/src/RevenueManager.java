
import java.util.List;

public class RevenueManager {
    private List<Transaction> transactions;

    public RevenueManager(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public double calculateRevenue() {
        double revenue = 0;
        for (Transaction transaction : transactions) {
            if ("Sale".equalsIgnoreCase(transaction.getType())) {
                revenue += transaction.getProduct().getPrice() * transaction.getQuantity();
            }
        }
        return revenue;
    }
}
class ExpensesManager {
    private List<Transaction> transactions;

    public ExpensesManager(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    public double calculateExpenses() {
        double expenses = 0;
        for (Transaction transaction : transactions) {
            if ("Purchase".equalsIgnoreCase(transaction.getType())) {
                expenses += transaction.getProduct().getPrice() * transaction.getQuantity();
            }
        }
        return expenses;
    }
}
