import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StockManagementGUI extends JFrame {
    private final DefaultListModel<StockItem> itemsListModel;
    private final JList<StockItem> itemsList;

    public StockManagementGUI() {
        // Set up the frame
        setTitle("Stock Management");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 300);
        setLocationRelativeTo(null);
        getContentPane().setBackground(Color.PINK);  // Set the background color to pink

        // Create the main panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        getContentPane().add(mainPanel);
        mainPanel.setBackground(Color.PINK);  // Set the background color to pink
        getContentPane().add(mainPanel);

        // Create the items list
        itemsListModel = new DefaultListModel<>();
        itemsList = new JList<>(itemsListModel);
        JScrollPane itemsScrollPane = new JScrollPane(itemsList);
        mainPanel.add(itemsScrollPane, BorderLayout.CENTER);

        // Create buttons
        JButton addItemButton = new JButton("Add Item");
        JButton removeItemButton = new JButton("Remove Item");
        JButton displayDetailsButton = new JButton("Display Details");
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addItemButton);
        buttonPanel.add(removeItemButton);
        buttonPanel.add(displayDetailsButton);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Add action listeners directly to the buttons
        addItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addItem();
            }
        });

        removeItemButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeItem();
            }
        });

        displayDetailsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayDetails();
            }
        });


        // Initialize the GUI with some sample data
        initializeSampleData();
    }

    private void initializeSampleData() {
        StockItem item1 = new StockItem("Item 1", "Description 1", 10, "Location 1");
        StockItem item2 = new StockItem("Item 2", "Description 2", 5, "Location 2");
        StockItem item3 = new StockItem("Item 3", "Description 3", 8, "Location 3");

        addItemToList(item1);
        addItemToList(item2);
        addItemToList(item3);
    }

    private void addItemToList(StockItem item) {
        itemsListModel.addElement(item);
    }

    private void removeItemFromList(StockItem item) {
        itemsListModel.removeElement(item);
    }

    private void addItem() {
        // Show input dialogs to get item details from the user
        String name = JOptionPane.showInputDialog("Enter item name:");
        String description = JOptionPane.showInputDialog("Enter item description:");
        String quantityStr = JOptionPane.showInputDialog("Enter item quantity:");
        int quantity = Integer.parseInt(quantityStr);
        String location = JOptionPane.showInputDialog("Enter item location:");

        // Create a new StockItem object with the provided details
        StockItem newItem = new StockItem(name, description, quantity, location);

        // Add the item to the list
        addItemToList(newItem);
    }

    private void removeItem() {
        // Get the selected item from the list
        StockItem selectedItem = itemsList.getSelectedValue();

        // Remove the selected item from the list
        if (selectedItem != null) {
            removeItemFromList(selectedItem);
        } else {
            JOptionPane.showMessageDialog(this, "No item selected.");
        }
    }

    private void displayDetails() {
        // Get the selected item from the list
        StockItem selectedItem = itemsList.getSelectedValue();

        // Display the details in a dialog box
        if (selectedItem != null) {
            String details = "Item: " + selectedItem.getName() + "\n"
                    + "Description: " + selectedItem.getDescription() + "\n"
                    + "Quantity: " + selectedItem.getQuantity() + "\n"
                    + "Location: " + selectedItem.getLocation();

            JOptionPane.showMessageDialog(this, details, "Item Details", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "No item selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

class StockTransaction {
    public StockTransaction(String orderId, StockItem item, int quantity, TransactionType transactionType) {
        this.item = item;
        this.transactionType = transactionType;
    }

    public enum TransactionType {
        ADD, // Represents adding stock
        REMOVE // Represents removing stock
    }

    private TransactionType transactionType;
    private StockItem item;
    private int quantity;

    public StockTransaction(String type, StockItem item, int quantity) {
        this.type = type;
        this.item = item;
        this.quantity = quantity;
        this.transactionType = transactionType;
    }

    private String type;
}

class StockItem {
    private final String name;
    private String description;
    private int quantity;
    private String location;

    public StockItem(String itemName) {
        this.name = itemName;
    }

    public StockItem(String name, String description, int quantity, String location) {
        this.name = name;
        this.description = description;
        this.quantity = quantity;
        this.location = location;
    }

    public StockItem(String name, int quantity) {
        this.name = name;
        this.quantity = quantity;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getLocation() {
        return location;
    }

}